#-------------------------------------------------#
# Title: Using Try/Except
# Dev:   Sara White
# Date:  November 15, 2018
# ChangeLog: new
#-------------------------------------------------#

#  Example of using exceptions for math operations

# The 1st grader calculator
while True:
    try:
        int1 = int(input('Choose a number: '))
        break
    except ValueError:
        print('That was in fact not a number for a 1st grader. Choose a number with no decimals or letters.')

while True:
    try:
        int2 = int(input('Choose another number: '))
        break
    except ValueError:
        print('That was in fact not a number for a 1st grader. Choose a number with no decimals or letters.')

# Do maths on the number
print('Addition:\n',int1, '+', int2, '=', int1 + int2)
print('Subtraction:\n', int1, '-', int2, '=', int1 - int2)
print('Multiplication:\n', int1, 'x', int2, '=', int1 * int2)
print('Division: ')
try:
    if int1 % int2 == 0:
        print(int1, '/', int2, '=', int(int1 / int2))
    else:
        print(int1, '/', int2, 'is not a whole number. Let\'s wait until 2nd grade to tackle this one.')
except ZeroDivisionError:
    print('Cannot divide by zero. You\'ll learn why when you\'re older. To infinity and beyond!')

