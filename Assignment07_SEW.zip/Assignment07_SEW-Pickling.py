#-------------------------------------------------#
# Title: Making Pickles and Composites
# Dev:   Sara White
# Date:  November 15, 2018
# ChangeLog: new
#-------------------------------------------------#

# Import
import pickle

# Create a dictionary of commonly used acronyms in the composites world
dicMaterialsAcronyms = {'GFRP': 'Glass fiber reinforced polymer',
                        'CFRP': 'Carbon fiber reinforced polymer',
                        'PW': 'Plain Weave',
                        '8H': '8 Harness Weave',
                        'PEK': 'polyetherketone'}

# Open and update dictionary
objFile = open('C:\\_PythonClass\\Assignment07_SEW\\MaterialsDictionary.dat', 'wb')
pickle.dump(dicMaterialsAcronyms, objFile)  # save file to .dat
objFile.close()

# Read dictionary to confirm it has worked
objFile = open('C:\\_PythonClass\\Assignment07_SEW\\MaterialsDictionary.dat', 'rb')
dictionary = pickle.load(objFile)  # load .dat file into dictionary
objFile.close()

# Search term
term = input('What acronym would you like to search for?: ')
if term in dictionary:  # Checks to make sure it has been defined
    print(term, 'stands for :', dictionary.get(term))
else:
    print('That acronym has not been defined.')