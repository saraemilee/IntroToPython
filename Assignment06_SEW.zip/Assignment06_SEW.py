#-------------------------------------------------#
# Title: Creating classes and methods
# Dev:   Sara White
# Date:  November 08, 2018
# ChangeLog: new
#-------------------------------------------------#

# -- data code --
objFileName = 'C:\_PythonClass\Assignment05_SEW\\todo.txt'
strData = ''
dicRow = {}
lstTable = []
saveCount = [1]  # Keeps track if user has made changes before exiting

#  -- processing code --

# Step 1 - Load data from a file
objFile = open(objFileName, 'r+')  # Open and read file
strData = objFile.readlines()  # Create strings of data from the file
objFile.close()

# load each "row" of data in into a python Dictionary and append to a list
for rows in strData:
    # Split data rows with comma delimiter, and remove any escape sequences
    dicRow = {rows.split(',')[0].strip().lower() : rows.split(',')[1].strip().lower()}
    #  Append dictionary to list "row"
    lstTable.append(dicRow)

print('\nThis program will open your to do list and allow you to make edits or view the contents\n')

#  Create a Class to hold a list of functions
class ToDoList(object):
    '''This class contains methods for processing items on a to do list'''

    # Define methods
    def PrintList(todolist):
        '''This function prints user's current to do list - Input must be list of dictionary rows'''
        print('TO DO LIST\n')
        # Print list with prettier formatting
        print('%-25s%-25s' % ('Task', 'Priority'))
        print('%-25s%-25s' % ('----', '--------'))
        for tasks in todolist:
            print('%-25s%-25s' % (*tasks, *tasks.values()))  # unpack dictionary items and print them
        print('\nEND OF LIST\n')

    def AddTask(todolist,saveCount):
        '''This function allows user to add to your to do list - Input must be list of dictionary rows'''
        addTask = input('What task would you like to add?: ')
        # Check dictionary to make sure task doesn't already exist
        if not any(rows.get(addTask.lower(), None) for rows in todolist):
            priority = input('What is the priority of ' + addTask + '? [ High | Medium | Low ]: ')
            todolist.append({addTask.lower(): priority.lower()})  # Append new dictionary item to existing list
            print(addTask,'has been added to your list with a', priority,'priority\n')
            saveCount[0] = 0
            return saveCount
        # Let user know if it does already exist
        else:
            print('That task already exists. Better luck next time fool. \n')

    def DelTask(todolist,saveCount):
        '''This function allows user to delete and item from to do list - Input must be list of dictionary rows'''
        delTask = input('What task would you like to remove?: ')
        # Check dictionary to make sure task does already exist
        if any(rows.get(delTask.lower(), None) for rows in todolist):
            for rows in todolist:
                if list(rows.keys()) == [delTask.lower()]:  # Iterates through rows looking for which row to delete
                    lstTable.remove(rows)
            print(delTask, 'has been removed from the list\n')
            saveCount[0] = 0
            return saveCount
        # Let user know if it does not exist
        else:
            print(delTask, 'currently does not exist. Better luck next time fool. \n')

    def SaveList(objFileName, todolist, saveCount):
        objFile = open(objFileName, 'w')
        for rows in todolist:
            for k, v in rows.items():
                objFile.write(str(k) + ', ' + str(v) + '\n')
        objFile.close()
        saveCount[0]=1
        print('Your most up to date to do list has been saved and is located at: ', objFileName, '\n')
        return saveCount
# -- Presentation (I/O) code --

print('Your current to do list that has been uploaded from', objFileName, 'is listed below')
ToDoList.PrintList(lstTable)

input('Press enter to access the menu...\n')

# Step 2 - Display a menu of choices to the user
while True:
    print ('''---------------
Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    ''')
    strChoice = str(input('Which option would you like to perform? [1 to 5] - '))
    print()  #adding a new line

    # Step 3 -Show the current items in the table
    if strChoice.strip() == '1':
        ToDoList.PrintList(lstTable)
        input('Press enter to return to menu...\n')

    # Step 4 - Add a new item to the list/Table
    elif strChoice.strip() == '2':
        ToDoList.AddTask(lstTable,saveCount)
        input('Press enter to return to menu...\n')

    # Step 5 - Remove a new item to the list/Table
    elif strChoice == '3':
        ToDoList.DelTask(lstTable,saveCount)
        input('Press enter to return to menu...\n')

    # Step 6 - Save tasks to the text file
    elif strChoice == '4':
        ToDoList.SaveList(objFileName,lstTable, saveCount)
        input('Press enter to return to menu...\n')

    # Step 7 - Allow user to exit
    elif strChoice == '5':
        if saveCount[0] == 1:
            # Exits if list has been saved with most recent changes
            input('Your to do list is up to date. Press enter to exit...\n')
        else:
            saveFile = input('Your list has not been saved with most recent changes. Would you like to save now?  [Yes or No] ')
            while saveFile.lower() not in ['yes', 'no']:
                # Makes sure user answers yes or no
                saveFile = input('Come again?  Would you like to save before exiting? This really shouldn\'t be that difficult. [Yes or No] ')
            if saveFile.lower() == 'yes':
                ToDoList.SaveList(objFileName, lstTable, saveCount)  # Saves list
                input('Press enter to exit...\n')
            elif saveFile.lower() == 'no':  # Exits without saving
                input('Your changes will not be saved. Press enter to exit...\n')
        break  # and Exit the program

    else:
        print('Unexpected Value. Try again. You can do it. I have complete faith in you')

