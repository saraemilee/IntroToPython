#-------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   Sara White
# Date:  October 30, 2018
# ChangeLog: new
#
#-------------------------------------------------#

objFileName = 'C:\_PythonClass\Assignment05_SEW\\todo.txt'
strData = ''
dicRow = {}
dicToDo = {}
lstTable = []


# Step 1 - Load data from a file
objFile = open(objFileName, 'r+')  # Open and read file
strData = objFile.readlines()  # Create strings of data from the file

for rows in strData:
    # load each "row" of data in "todo.txt" into a python Dictionary.
    dicRow = {rows.split(',')[0].strip().lower() : rows.split(',')[1].strip().lower()}
    dicToDo.update(dicRow)
    lstTable.append(dicRow)  # Add the each dictionary "row" to a python list "table"

print('This program will open your to do list and allow you to make edits or view the contents\n')
print('Your current to do list is below')
print('''Task       Priority
----       --------''')
for tasks in lstTable:
    print(*tasks, '\t', *tasks.values())  # unpack dictionary items and print them
print('\nEnd of list\n')

input('Press enter to access the menu...')
# Step 2 - Display a menu of choices to the user
while True:
    print ('''---------------
Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    ''')
    strChoice = str(input('Which option would you like to perform? [1 to 5] - '))
    print()  #adding a new line

    # Step 3 -Show the current items in the table
    if strChoice.strip() == '1':
        print('TO DO LIST')
        print('''Task       Priority
----       --------''')
        for tasks in lstTable:
            print(*tasks,'\t',*tasks.values())  # unpack dictionary items and print them
        print('\nEnd of list\n')
        input('Press enter to return to menu...\n')
    # Step 4 - Add a new item to the list/Table
    elif strChoice.strip() == '2':
        addTask = input('What task would you like to add?: ')
        if addTask.lower() not in dicToDo:
            priority = input('What is the priority of this task?: ')
            dicRow = {addTask.lower(): priority.lower()}
            dicToDo.update(dicRow)
            lstTable.append(dicRow)
            print(addTask,'has been added to your list with a', priority,'priority\n')
        else:
            print('That task already exists. Better luck next time fool. \n')
        input('Press enter to return to menu...\n')
    # Step 5 - Remove a new item to the list/Table
    elif strChoice == '3':
        delTask = input('What task would you like to remove?: ')
        if delTask.lower() in dicToDo:
            del dicToDo[delTask.lower()]
            for rows in lstTable:
                if list(rows.keys()) == [delTask.lower()]:
                    lstTable.remove(rows)
                    print(delTask, 'has been removed from the list\n')
        else:
            print('That task currently does not exist. Better luck next time fool.\n')
        input('Press enter to return to menu...\n')
    # Step 6 - Save tasks to the ToDo.txt file
    elif strChoice == '4':
        objFile.close()
        objFile = open(objFileName, 'w')
        for rows in lstTable:
            for k, v in rows.items():
                objFile.write(str(k) + ',\t' + str(v) + '\n')
        print('Your most up to date to do list has been saved and is located at: ',objFileName,'\n')
        input('Press enter to return to menu...\n')
    elif strChoice == '5':
        input('Press enter to exit...\n')
        break # and Exit the program
    else:
        print('Unexpected Value. Try again. You can do it. I have complete faith in you')

objFile.close()

# Save to do list to a file before closing
objFile = open(objFileName, 'w')
for rows in lstTable:
    for k, v in rows.items():
        objFile.write(str(k) + ',\t' + str(v) + '\n')
print('Your most up to date to do list has been saved and is located at: ',objFileName,'\n')
objFile.close()